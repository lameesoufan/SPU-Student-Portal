import React, { useState, useRef } from 'react';
import { uploadReferenceDb } from '../api';
import './ImportUsers.css';

const Icons = {
  Database: <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/></svg>,
  UploadAction: <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>,
  FileUp: <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="12" y1="18" x2="12" y2="12"/><polyline points="9 15 12 12 15 15"/></svg>,
};

export default function UploadReference() {
  const [file, setFile]       = useState(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState(null);
  const fileRef = useRef();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!file) { setMessage({ type: 'error', text: 'Please select a file.' }); return; }
    setLoading(true);
    setMessage(null);
    try {
      const res = await uploadReferenceDb(file);
      setMessage({ type: 'success', text: res.data.message });
      setFile(null);
      fileRef.current.value = '';
    } catch (err) {
      setMessage({ type: 'error', text: err.response?.data?.error || 'Upload failed.' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="premium-dashboard import-wrapper">
      <div className="page-header">
        <h1>Upload Reference Database</h1>
        <p>Upload the official university student records file for self-registration verification.</p>
      </div>

      {/* Info Banner */}
      <div className="import-info-banner">
        <div className="import-info-icon">{Icons.Database}</div>
        <div className="import-info-text">
          <strong>How it works:</strong> Upload the official university student records file. Students will use their
          University ID to self-register — the system will verify against this file.
          <br />
          <span className="text-sm text-muted" style={{ display: 'inline-block', marginTop: '6px' }}>
            Required columns: <code>university_id</code> | <code>full_name</code> | <code>department</code> | <code>year</code> | <code>email</code> <span className="text-muted">(optional)</span>
          </span>
        </div>
      </div>

      {/* Upload Card */}
      <div className="card import-card" style={{ maxWidth: 640 }}>
        <div className="card-body">
          <form onSubmit={handleSubmit}>
            {message && (
              <div className={`alert ${message.type === 'success' ? 'alert-success' : 'alert-error'}`} role="alert">
                {message.text}
              </div>
            )}

            <div className="form-group">
              <label htmlFor="ref-file">Reference File (.xlsx / .csv)</label>
              <div
                className={`import-drop-zone ${file ? 'has-file' : ''}`}
                onClick={() => fileRef.current.click()}
              >
                <div className="import-drop-icon">
                  {file ? Icons.FileUp : Icons.UploadAction}
                </div>
                <div className="import-drop-text">
                  <span className="import-drop-title">{file ? file.name : 'Click to browse or drop file here'}</span>
                  <span className="import-drop-subtitle">Excel or CSV files (Max 10MB)</span>
                </div>
                <input
                  id="ref-file"
                  ref={fileRef}
                  type="file"
                  accept=".xlsx,.xls,.csv"
                  style={{ display: 'none' }}
                  onChange={(e) => setFile(e.target.files[0] || null)}
                  aria-label="Upload reference database file"
                />
              </div>
            </div>

            <button className="btn btn-primary btn-lg import-submit-btn" type="submit" disabled={loading}>
              {loading ? 'Uploading…' : 'Upload Reference Database'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
