import React, { useEffect, useState } from 'react';
import { fetchMyIdeas } from '../api';
import './MyIdeas.css';

const STATUS_META = {
  pending_review: { label: 'Pending Review', cls: 'badge-warning' },
  approved:       { label: 'Approved',        cls: 'badge-success' },
  rejected:       { label: 'Rejected',        cls: 'badge-danger' },
};

export default function MyIdeas({ onBack, onSubmitNew }) {
  const [ideas, setIdeas]     = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState('');

  useEffect(() => {
    fetchMyIdeas()
      .then((res) => setIdeas(res.data))
      .catch(() => setError('Failed to load ideas. Please try again.'))
      .finally(() => setLoading(false));
  }, []);

  const counts = {
    pending_review: ideas.filter((i) => i.status === 'pending_review').length,
    approved:       ideas.filter((i) => i.status === 'approved').length,
    rejected:       ideas.filter((i) => i.status === 'rejected').length,
  };

  return (
    <div className="my-ideas-wrap">
      {/* Header */}
      <div className="page-header my-ideas-header">
        <button className="back-btn" onClick={onBack}>← Back to Dashboard</button>
        <div className="my-ideas-header-row">
          <div>
            <h1>My Project Ideas</h1>
            <p>Manage and track your submitted project ideas.</p>
          </div>
          <button className="btn btn-primary" onClick={onSubmitNew}>+ Submit New Idea</button>
        </div>
      </div>

      <div className="my-ideas-content">
        {/* Summary strip */}
        <div className="my-ideas-summary">
          <div className="my-ideas-summary-card">
            <span className="my-ideas-summary-count">{counts.pending_review}</span>
            <span className="my-ideas-summary-label">Pending Review</span>
          </div>
          <div className="my-ideas-summary-card my-ideas-summary-card--success">
            <span className="my-ideas-summary-count">{counts.approved}</span>
            <span className="my-ideas-summary-label">Approved</span>
          </div>
          <div className="my-ideas-summary-card my-ideas-summary-card--danger">
            <span className="my-ideas-summary-count">{counts.rejected}</span>
            <span className="my-ideas-summary-label">Rejected</span>
          </div>
        </div>

        {/* Content */}
        {loading && (
          <div className="empty-state">
            <div className="spinner-dark" style={{ width: 24, height: 24 }}></div>
            <p className="text-muted" style={{ marginTop: 12 }}>Loading ideas…</p>
          </div>
        )}

        {error && <div className="alert alert-error" role="alert">{error}</div>}

        {!loading && !error && ideas.length === 0 && (
          <div className="card">
            <div className="empty-state">
              <div className="my-ideas-empty-icon">
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M9 11l3 3L22 4"/>
                  <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>
                </svg>
              </div>
              <h3>No ideas yet</h3>
              <p>You haven't submitted any project ideas yet. Start by proposing your first idea.</p>
              <button className="btn btn-primary" onClick={onSubmitNew}>Submit Your First Idea</button>
            </div>
          </div>
        )}

        {!loading && ideas.length > 0 && (
          <div className="my-ideas-list">
            {ideas.map((idea) => {
              const meta = STATUS_META[idea.status] || STATUS_META.pending_review;
              return (
                <div key={idea.id} className="card my-ideas-card">
                  <div className="card-body">
                    <div className="my-ideas-card-top">
                      <div className="my-ideas-card-title-row">
                        <h3 className="my-ideas-card-title">{idea.title}</h3>
                        <span className={`badge ${meta.cls}`}>{meta.label}</span>
                      </div>
                      <p className="my-ideas-card-desc">{idea.description}</p>
                    </div>

                    <div className="my-ideas-card-meta">
                      <span className="my-ideas-tag">{idea.department.replace(/_/g, ' ')}</span>
                      <span className="my-ideas-tag">{idea.max_team_size} students</span>
                      {idea.required_skills && (
                        <span className="my-ideas-tag">{idea.required_skills}</span>
                      )}
                      <span className="my-ideas-tag my-ideas-tag--date">{new Date(idea.created_at).toLocaleDateString()}</span>
                    </div>

                    {idea.status === 'rejected' && idea.rejection_reason && (
                      <div className="alert alert-error" style={{ margin: 0 }}>
                        <strong>Rejection reason:</strong> {idea.rejection_reason}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
