import React from 'react';
import './Navbar.css';
import NotificationBell from './NotificationBell';
import { useTheme } from '../ThemeContext';

const ROLE_LABELS = {
  dean: 'Dean',
  admin: 'Administrator',
  hod: 'Head of Department',
  doctor: 'Doctor',
  student: 'Student',
};

/* SVG Icons for theme toggle */
const SunIcon = ({ size = 20 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="5"/>
    <line x1="12" y1="1" x2="12" y2="3"/>
    <line x1="12" y1="21" x2="12" y2="23"/>
    <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/>
    <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/>
    <line x1="1" y1="12" x2="3" y2="12"/>
    <line x1="21" y1="12" x2="23" y2="12"/>
    <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/>
    <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>
  </svg>
);

const MoonIcon = ({ size = 20 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
  </svg>
);

export default function Navbar({ user, onLogout, currentPage }) {
  const { theme, toggleTheme } = useTheme();
  const showBell = ['student', 'doctor', 'hod'].includes(user.role);

  const getBreadcrumb = () => {
    const roleName = ROLE_LABELS[user.role] || user.role;
    if (!currentPage || currentPage === 'dashboard') return roleName;
    const pageName = currentPage.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
    return `${roleName} / ${pageName}`;
  };

  return (
    <nav className="navbar" role="navigation" aria-label="Main navigation">
      <div className="navbar-left">
        <div className="navbar-brand">
          <span className="navbar-logo" aria-hidden="true">🎓</span>
          <span className="navbar-title">SPU Portal</span>
        </div>
        <div className="breadcrumbs" aria-label="Breadcrumbs">
          <span className="breadcrumb-item">Home</span>
          <span className="breadcrumb-separator">/</span>
          <span className="breadcrumb-current">{getBreadcrumb()}</span>
        </div>
      </div>

      <div className="navbar-user">
        <button
          className="theme-toggle-btn"
          onClick={toggleTheme}
          aria-label={theme === 'light' ? 'Switch to dark theme' : 'Switch to light theme'}
          title={theme === 'light' ? 'Switch to dark theme' : 'Switch to light theme'}
        >
          {theme === 'light' ? <MoonIcon size={18} /> : <SunIcon size={18} />}
        </button>
        {showBell && <NotificationBell />}
        <div className="user-profile-trigger">
          <div className="user-info">
            <span className="user-name">{user.username}</span>
            <span className="user-role">{ROLE_LABELS[user.role] || user.role}</span>
          </div>
          <button className="btn btn-outline-danger navbar-logout" onClick={onLogout} aria-label="Sign out">
            Sign Out
          </button>
        </div>
      </div>
    </nav>
  );
}
