import React, { useState, useEffect } from 'react';
import { login } from '../api';
import './Login.css';

export default function Login({ onLogin, onRegister }) {
  const [form, setForm] = useState({ username: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [focusedField, setFocusedField] = useState(null);

  useEffect(() => {
    const t = setTimeout(() => setMounted(true), 100);
    return () => clearTimeout(t);
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await login(form.username, form.password);
      localStorage.setItem('access', res.data.access);
      localStorage.setItem('refresh', res.data.refresh);
      const payload = JSON.parse(atob(res.data.access.split('.')[1]));
      onLogin({
        username: form.username,
        role: payload.role,
        must_change_password: payload.must_change_password,
        department: payload.department,
      });
    } catch (err) {
      setError(err.response?.data?.detail || 'Invalid username or password.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={`lp-wrapper ${mounted ? 'lp-mounted' : ''}`}>
      {/* Animated background particles */}
      <div className="lp-particles" aria-hidden="true">
        {[...Array(6)].map((_, i) => (
          <div key={i} className={`lp-particle lp-particle-${i + 1}`} />
        ))}
      </div>

      {/* Gradient overlay */}
      <div className="lp-overlay" />

      {/* Content */}
      <div className="lp-content">
        {/* Left branding panel */}
        <div className={`lp-brand ${mounted ? 'lp-brand-visible' : ''}`}>
          <div className="lp-brand-badge">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M22 10v6M2 10l10-5 10 5-10 5z" /><path d="M6 12v5c0 2 6 3 6 3s6-1 6-3v-5" />
            </svg>
            <span>SPU</span>
          </div>

          <div className="lp-brand-text">
            <h1>Syrian Private University</h1>
            <div className="lp-brand-divider" />
            <p className="lp-brand-tagline">
              Everything you need to manage<br />your graduation project — in one place.
            </p>
          </div>

          <div className="lp-brand-features">
            <div className="lp-feature">
              <div className="lp-feature-icon">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" /><rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" />
                </svg>
              </div>
              <div>
                <strong>Kanban Boards</strong>
                <span>Track tasks visually</span>
              </div>
            </div>
            <div className="lp-feature">
              <div className="lp-feature-icon">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
                </svg>
              </div>
              <div>
                <strong>Workflow Automation</strong>
                <span>Streamline your process</span>
              </div>
            </div>
            <div className="lp-feature">
              <div className="lp-feature-icon">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22" />
                </svg>
              </div>
              <div>
                <strong>GitLab Integration</strong>
                <span>Code & commit tracking</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right login card (Glassmorphism) */}
        <div className={`lp-card ${mounted ? 'lp-card-visible' : ''}`}>
          <div className="lp-card-glow" aria-hidden="true" />

          <div className="lp-card-inner">
            {/* Mobile-only branding */}
            <div className="lp-mobile-brand">
              <div className="lp-mobile-logo">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M22 10v6M2 10l10-5 10 5-10 5z" /><path d="M6 12v5c0 2 6 3 6 3s6-1 6-3v-5" />
                </svg>
              </div>
              <span>SPU Portal</span>
            </div>

            <div className="lp-card-header">
              <h2>Welcome back</h2>
              <p>Sign in to your academic portal</p>
            </div>

            <form onSubmit={handleSubmit} className="lp-form" noValidate>
              {error && (
                <div className="lp-error" role="alert">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="10" /><line x1="15" y1="9" x2="9" y2="15" /><line x1="9" y1="9" x2="15" y2="15" />
                  </svg>
                  {error}
                </div>
              )}

              <div className={`lp-field ${focusedField === 'username' ? 'lp-field-focused' : ''} ${form.username ? 'lp-field-filled' : ''}`}>
                <label htmlFor="username">Username</label>
                <div className="lp-input-wrap">
                  <svg className="lp-input-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" />
                  </svg>
                  <input
                    id="username"
                    type="text"
                    placeholder=" "
                    value={form.username}
                    onChange={(e) => setForm({ ...form, username: e.target.value })}
                    onFocus={() => setFocusedField('username')}
                    onBlur={() => setFocusedField(null)}
                    required
                    autoComplete="username"
                  />
                </div>
              </div>

              <div className={`lp-field ${focusedField === 'password' ? 'lp-field-focused' : ''} ${form.password ? 'lp-field-filled' : ''}`}>
                <label htmlFor="password">Password</label>
                <div className="lp-input-wrap">
                  <svg className="lp-input-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" />
                  </svg>
                  <input
                    id="password"
                    type="password"
                    placeholder=" "
                    value={form.password}
                    onChange={(e) => setForm({ ...form, password: e.target.value })}
                    onFocus={() => setFocusedField('password')}
                    onBlur={() => setFocusedField(null)}
                    required
                    autoComplete="current-password"
                  />
                </div>
              </div>

              <button className="lp-submit" type="submit" disabled={loading}>
                <span className="lp-submit-text">
                  {loading ? 'Signing in...' : 'Sign In'}
                </span>
                {loading && <span className="lp-submit-spinner" />}
                {!loading && (
                  <svg className="lp-submit-arrow" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <line x1="5" y1="12" x2="19" y2="12" /><polyline points="12 5 19 12 12 19" />
                  </svg>
                )}
              </button>
            </form>

            {onRegister && (
              <div className="lp-register-cue">
                <span>New to the portal?</span>
                <button type="button" onClick={onRegister} className="lp-register-link">
                  Create your account
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <line x1="5" y1="12" x2="19" y2="12" /><polyline points="12 5 19 12 12 19" />
                  </svg>
                </button>
              </div>
            )}

            <footer className="lp-footer">
              &copy; {new Date().getFullYear()} Syrian Private University &middot; Faculty of AI Engineering
            </footer>
          </div>
        </div>
      </div>
    </div>
  );
}
