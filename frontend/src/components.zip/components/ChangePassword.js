import React, { useState } from 'react';
import { changePassword } from '../api';
import './ChangePassword.css';

export default function ChangePassword({ user, onSuccess }) {
  const [form, setForm] = useState({ new_password: '', confirm_password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (form.new_password !== form.confirm_password) {
      setError('Passwords do not match.');
      return;
    }

    setLoading(true);
    try {
      await changePassword(form.new_password, form.confirm_password);
      onSuccess();
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to change password.');
    } finally {
      setLoading(false);
    }
  };

  const set = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  return (
    <div className="cp-page">
      <div className="card cp-card">
        <div className="cp-card-header">
          <div className="cp-icon" aria-hidden="true">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
              <path d="M7 11V7a5 5 0 0 1 10 0v4" />
            </svg>
          </div>
          <h1 className="cp-title">Change Your Password</h1>
          <p className="cp-subtitle">You must set a new password before continuing</p>
        </div>

        <div className="card-body cp-card-body">
          <div className="cp-info" role="note">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <circle cx="12" cy="12" r="10" />
              <line x1="12" y1="16" x2="12" y2="12" />
              <line x1="12" y1="8" x2="12.01" y2="8" />
            </svg>
            <span>
              Your current password is your university ID (<strong>{user.username}</strong>).
              Please choose a new secure password.
            </span>
          </div>

          {error && <div className="alert alert-error" role="alert">{error}</div>}

          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="new_password">New Password</label>
              <input
                id="new_password"
                className="form-control"
                type="password"
                placeholder="At least 8 characters"
                value={form.new_password}
                onChange={set('new_password')}
                required
                autoComplete="new-password"
              />
            </div>

            <div className="form-group">
              <label htmlFor="confirm_password">Confirm Password</label>
              <input
                id="confirm_password"
                className="form-control"
                type="password"
                placeholder="Repeat your new password"
                value={form.confirm_password}
                onChange={set('confirm_password')}
                required
                autoComplete="new-password"
              />
            </div>

            {/* Password strength hints */}
            <ul className="cp-hints" aria-label="Password requirements">
              <li className={form.new_password.length >= 8 ? 'hint--ok' : ''}>
                At least 8 characters
              </li>
              <li className={/[a-zA-Z]/.test(form.new_password) ? 'hint--ok' : ''}>
                Contains letters
              </li>
              <li className={form.new_password !== user.username || !form.new_password ? 'hint--ok' : 'hint--fail'}>
                Not the same as your university ID
              </li>
            </ul>

            <button className="btn btn-primary cp-submit" type="submit" disabled={loading}>
              {loading ? (
                <>
                  <span className="spinner"></span>
                  Saving…
                </>
              ) : (
                'Set New Password'
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
