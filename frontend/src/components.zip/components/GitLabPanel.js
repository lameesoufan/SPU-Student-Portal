import React, { useState, useEffect } from 'react';
import {
  getGitLabAccountStatus,
  linkGitLabAccount,
  verifyGitLabToken,
  getBoardGitLabInfo,
  createGitLabProject,
  getBoardMembers,
  addBoardMember,
  removeBoardMember,
  getBoardCommits,
  syncCommits,
  getBoardCommitStats,
} from '../gitlabApi';
import './GitLabPanel.css';

const ACCESS_LEVELS = {
  10: 'ضيف',
  20: 'مراقب',
  30: 'مطور',
  40: 'مسؤول',
  50: 'مالك',
};

export default function GitLabPanel({ boardId, canManage = false }) {
  const [activeTab, setActiveTab] = useState('overview');
  const [loading, setLoading] = useState(true);
  const [accountStatus, setAccountStatus] = useState(null);
  const [gitlabProject, setGitlabProject] = useState(null);
  const [members, setMembers] = useState([]);
  const [commits, setCommits] = useState([]);
  const [stats, setStats] = useState(null);
  const [error, setError] = useState('');

  // Modals
  const [showLinkModal, setShowLinkModal] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showAddMemberModal, setShowAddMemberModal] = useState(false);

  // Form state
  const [tokenInput, setTokenInput] = useState('');
  const [tokenVerified, setTokenVerified] = useState(null);
  const [verifiedInfo, setVerifiedInfo] = useState(null);
  const [repoName, setRepoName] = useState('');
  const [repoVisibility, setRepoVisibility] = useState('private');
  const [newMemberUsername, setNewMemberUsername] = useState('');
  const [newMemberLevel, setNewMemberLevel] = useState(30);
  const [actionLoading, setActionLoading] = useState(false);

  // Load initial data
  useEffect(() => {
    loadData();
  }, [boardId]);

  const loadData = async () => {
    setLoading(true);
    setError('');
    try {
      const [statusRes, projectRes] = await Promise.all([
        getGitLabAccountStatus(),
        getBoardGitLabInfo(boardId),
      ]);
      setAccountStatus(statusRes.data);
      if (projectRes.data.success && projectRes.data.data) {
        setGitlabProject(projectRes.data.data);
        loadProjectData(boardId);
      }
    } catch (err) {
      setError('فشل في تحميل بيانات GitLab');
    } finally {
      setLoading(false);
    }
  };

  const loadProjectData = async (bid) => {
    try {
      const [membersRes, statsRes] = await Promise.all([
        getBoardMembers(bid),
        getBoardCommitStats(bid),
      ]);
      setMembers(membersRes.data.data || []);
      setStats(statsRes.data.data || null);
    } catch (err) {
      console.error('Failed to load project data:', err);
    }
  };

  const loadCommits = async (bid, page = 1) => {
    try {
      const res = await getBoardCommits(bid, { page, limit: 20 });
      setCommits(res.data.data || []);
    } catch (err) {
      console.error('Failed to load commits:', err);
    }
  };

  const handleVerifyToken = async () => {
    if (!tokenInput.trim()) return;
    setActionLoading(true);
    setTokenVerified(null);
    try {
      const res = await verifyGitLabToken(tokenInput.trim());
      setTokenVerified(true);
      setVerifiedInfo(res.data);
    } catch (err) {
      setTokenVerified(false);
    } finally {
      setActionLoading(false);
    }
  };

  const handleLinkAccount = async () => {
    setActionLoading(true);
    try {
      const res = await linkGitLabAccount(tokenInput.trim());
      setAccountStatus({ is_linked: true, data: res.data.data });
      setShowLinkModal(false);
      setTokenInput('');
      setTokenVerified(null);
      setVerifiedInfo(null);
    } catch (err) {
      setError(err.response?.data?.message || 'فشل ربط الحساب');
    } finally {
      setActionLoading(false);
    }
  };

  const handleCreateRepo = async () => {
    setActionLoading(true);
    setError('');
    try {
      const res = await createGitLabProject(boardId, {
        project_name: repoName || undefined,
        visibility: repoVisibility,
      });
      setGitlabProject(res.data.data);
      setShowCreateModal(false);
      setRepoName('');
      loadProjectData(boardId);
    } catch (err) {
      setError(err.response?.data?.message || 'فشل إنشاء المستودع');
    } finally {
      setActionLoading(false);
    }
  };

  const handleAddMember = async () => {
    if (!newMemberUsername.trim()) return;
    setActionLoading(true);
    setError('');
    try {
      await addBoardMember(boardId, newMemberUsername.trim(), newMemberLevel);
      setShowAddMemberModal(false);
      setNewMemberUsername('');
      const res = await getBoardMembers(boardId);
      setMembers(res.data.data || []);
    } catch (err) {
      setError(err.response?.data?.message || 'فشل إضافة العضو');
    } finally {
      setActionLoading(false);
    }
  };

  const handleRemoveMember = async (gitlabUserId) => {
    if (!window.confirm('هل أنت متأكد من حذف هذا العضو؟')) return;
    setError('');
    try {
      await removeBoardMember(boardId, gitlabUserId);
      const res = await getBoardMembers(boardId);
      setMembers(res.data.data || []);
    } catch (err) {
      setError(err.response?.data?.message || 'فشل حذف العضو');
    }
  };

  const handleSyncCommits = async () => {
    setError('');
    try {
      const res = await syncCommits(boardId);
      loadCommits(boardId);
      loadProjectData(boardId);
      alert(res.data.message);
    } catch (err) {
      setError(err.response?.data?.message || 'فشلت المزامنة');
    }
  };

  const handleTabChange = (tab) => {
    setActiveTab(tab);
    if (tab === 'commits' && gitlabProject) {
      loadCommits(boardId);
    }
  };

  // ===== LOADING STATE =====
  if (loading) {
    return (
      <div className="gitlab-panel-loading">
        <div className="spinner-dark"></div>
        <p>جاري تحميل بيانات GitLab...</p>
      </div>
    );
  }

  // ===== NO GITLAB PROJECT STATE =====
  if (!gitlabProject) {
    return (
      <div className="gitlab-panel">
        {error && <div className="alert">{error}</div>}

        <div className="empty-state gitlab-empty-state">
          <div className="gitlab-empty-icon">📦</div>
          <h3>لا يوجد مستودع GitLab مرتبط بهذا المشروع</h3>
          <p>قم بإنشاء مستودع GitLab لتتبع الكود والتعاون مع فريقك</p>

          {!accountStatus?.is_linked ? (
            <button className="btn btn-primary" onClick={() => setShowLinkModal(true)}>
              🔗 ربط حساب GitLab
            </button>
          ) : (
            <button className="btn btn-primary" onClick={() => setShowCreateModal(true)}>
              ➕ إنشاء مستودع جديد
            </button>
          )}
        </div>

        {/* Account Info */}
        {accountStatus?.is_linked && (
          <div className="gitlab-account-info">
            <span className="gitlab-linked-badge">✓ مرتبط</span>
            <span>{accountStatus.data.gitlab_username}</span>
          </div>
        )}

        {/* Link Account Modal */}
        {showLinkModal && (
          <div className="gitlab-modal-overlay" onClick={() => setShowLinkModal(false)}>
            <div className="gitlab-modal" onClick={(e) => e.stopPropagation()}>
              <h3>🔗 ربط حساب GitLab</h3>
              <p className="gitlab-modal-desc">
                أدخل Personal Access Token من GitLab. يمكنك إنشاءه من:
                <br />
                <strong>GitLab → Profile → Access Tokens</strong>
              </p>

              <div className="form-group">
                <label>Personal Access Token</label>
                <input
                  type="password"
                  className="form-control"
                  value={tokenInput}
                  onChange={(e) => { setTokenInput(e.target.value); setTokenVerified(null); }}
                  placeholder="glpat-..."
                />
                <button
                  className="btn btn-outline"
                  onClick={handleVerifyToken}
                  disabled={!tokenInput.trim() || actionLoading}
                >
                  {actionLoading ? 'جاري التحقق...' : 'تحقق'}
                </button>
              </div>

              {tokenVerified && verifiedInfo && (
                <div className="gitlab-verify-success">
                  <p>✓ Token صالح</p>
                  <p>المستخدم: <strong>{verifiedInfo.username}</strong> ({verifiedInfo.name})</p>
                  <button className="btn btn-primary" onClick={handleLinkAccount}>
                    ربط الحساب
                  </button>
                </div>
              )}

              {tokenVerified === false && (
                <div className="gitlab-verify-error">
                  <p>✗ Token غير صالح. تأكد من صحته وحاول مرة أخرى.</p>
                </div>
              )}

              <button className="btn btn-ghost" onClick={() => setShowLinkModal(false)}>إلغاء</button>
            </div>
          </div>
        )}
      </div>
    );
  }

  // ===== GITLAB PROJECT EXISTS =====
  return (
    <div className="gitlab-panel">
      {error && <div className="alert">{error}</div>}

      {/* Header */}
      <div className="gitlab-project-header">
        <div className="gitlab-project-info">
          <h3>
            <span className="gitlab-icon">🦊</span>
            {gitlabProject.project_name || gitlabProject.gitlab_project_path}
          </h3>
          <span className={`gitlab-visibility-badge ${gitlabProject.visibility}`}>
            {gitlabProject.visibility}
          </span>
        </div>
        <div className="gitlab-project-actions">
          <a href={gitlabProject.web_url} target="_blank" rel="noopener noreferrer" className="gitlab-btn-open">
            فتح في GitLab ↗
          </a>
          <button className="btn btn-outline btn-sm" onClick={handleSyncCommits}>
            🔄 مزامنة
          </button>
          {canManage && (
            <button className="btn btn-outline btn-sm" onClick={() => setShowAddMemberModal(true)}>
              ➕ إضافة عضو
            </button>
          )}
        </div>
      </div>

      {/* Account Info */}
      <div className="gitlab-account-bar">
        {accountStatus?.is_linked ? (
          <span>
            <span className="gitlab-linked-badge">✓</span>
            مرتبط بـ: <strong>{accountStatus.data.gitlab_username}</strong>
          </span>
        ) : (
          <span className="gitlab-not-linked">
            ⚠️ حسابك غير مربوط بـ GitLab -
            <button className="gitlab-link-inline" onClick={() => setShowLinkModal(true)}>ربط الحساب</button>
          </span>
        )}
      </div>

      {/* Tabs */}
      <div className="gitlab-tabs">
        <button
          className={`gitlab-tab ${activeTab === 'overview' ? 'active' : ''}`}
          onClick={() => handleTabChange('overview')}
        >
          📊 نظرة عامة
        </button>
        <button
          className={`gitlab-tab ${activeTab === 'commits' ? 'active' : ''}`}
          onClick={() => handleTabChange('commits')}
        >
          📝 Commits
        </button>
        <button
          className={`gitlab-tab ${activeTab === 'members' ? 'active' : ''}`}
          onClick={() => handleTabChange('members')}
        >
          👥 الأعضاء
        </button>
      </div>

      {/* Tab Content */}
      <div className="gitlab-tab-content">
        {activeTab === 'overview' && (
          <div className="gitlab-overview">
            {stats && stats.has_gitlab_project ? (
              <>
                <div className="gitlab-stats-grid">
                  <div className="gitlab-stat-card">
                    <div className="gitlab-stat-value">{stats.total_commits}</div>
                    <div className="gitlab-stat-label">إجمالي Commits</div>
                  </div>
                  <div className="gitlab-stat-card">
                    <div className="gitlab-stat-value">{stats.total_authors}</div>
                    <div className="gitlab-stat-label">المساهمون</div>
                  </div>
                  <div className="gitlab-stat-card">
                    <div className="gitlab-stat-value">+{stats.total_lines_added}</div>
                    <div className="gitlab-stat-label">أسطر مضافة</div>
                  </div>
                  <div className="gitlab-stat-card">
                    <div className="gitlab-stat-value">-{stats.total_lines_removed}</div>
                    <div className="gitlab-stat-label">أسطر محذوفة</div>
                  </div>
                </div>

                {stats.last_commit && (
                  <div className="gitlab-last-commit">
                    <h4>آخر Commit</h4>
                    <div className="gitlab-commit-item">
                      <code>{stats.last_commit.sha}</code>
                      <span>{stats.last_commit.message}</span>
                      <span className="gitlab-commit-meta">
                        {stats.last_commit.author} - {stats.last_commit.date ? new Date(stats.last_commit.date).toLocaleDateString('ar') : ''}
                      </span>
                    </div>
                  </div>
                )}

                {stats.authors && stats.authors.length > 0 && (
                  <div className="gitlab-authors-section">
                    <h4>المساهمون</h4>
                    {stats.authors.map((a, i) => (
                      <div key={i} className="gitlab-author-bar">
                        <span className="gitlab-author-name">{a.author_name}</span>
                        <span className="gitlab-author-commits">{a.commit_count} commits</span>
                        <div className="gitlab-author-stats">
                          <span className="gitlab-added">+{a.added || 0}</span>
                          <span className="gitlab-removed">-{a.removed || 0}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </>
            ) : (
              <p>لا توجد إحصائيات بعد. ابدأ بالعمل على المشروع!</p>
            )}
          </div>
        )}

        {activeTab === 'commits' && (
          <div className="gitlab-commits-list">
            {commits.length === 0 ? (
              <div className="empty-state">
                <p>لا توجد Commits بعد</p>
                <button className="btn btn-outline" onClick={handleSyncCommits}>
                  🔄 مزامنة من GitLab
                </button>
              </div>
            ) : (
              commits.map((commit) => (
                <div key={commit.id} className="gitlab-commit-card">
                  <div className="gitlab-commit-header">
                    <code className="gitlab-commit-sha">{commit.short_sha}</code>
                    <span className="gitlab-commit-msg">{commit.short_message}</span>
                  </div>
                  <div className="gitlab-commit-meta-row">
                    <span>👤 {commit.author_name}</span>
                    <span>📅 {commit.authored_date ? new Date(commit.authored_date).toLocaleDateString('ar') : ''}</span>
                    <span className="gitlab-commit-lines">
                      <span className="gitlab-added">+{commit.added_lines}</span>
                      <span className="gitlab-removed">-{commit.removed_lines}</span>
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {activeTab === 'members' && (
          <div className="gitlab-members-list">
            {members.length === 0 ? (
              <p>لا يوجد أعضاء</p>
            ) : (
              members.map((member) => (
                <div key={member.id} className="gitlab-member-card">
                  <div className="gitlab-member-avatar">
                    {member.avatar_url ? (
                      <img src={member.avatar_url} alt={member.username} />
                    ) : (
                      <span>{(member.name || member.username)[0].toUpperCase()}</span>
                    )}
                  </div>
                  <div className="gitlab-member-info">
                    <strong>{member.name}</strong>
                    <span>@{member.username}</span>
                  </div>
                  <span className={`gitlab-access-badge level-${member.access_level}`}>
                    {ACCESS_LEVELS[member.access_level] || member.access_level}
                  </span>
                  {canManage && member.access_level < 50 && (
                    <button
                      className="gitlab-btn-remove"
                      onClick={() => handleRemoveMember(member.id)}
                    >
                      ✕
                    </button>
                  )}
                </div>
              ))
            )}
          </div>
        )}
      </div>

      {/* Link Account Modal */}
      {showLinkModal && (
        <div className="gitlab-modal-overlay" onClick={() => setShowLinkModal(false)}>
          <div className="gitlab-modal" onClick={(e) => e.stopPropagation()}>
            <h3>🔗 ربط حساب GitLab</h3>
            <p className="gitlab-modal-desc">
              أدخل Personal Access Token من GitLab.
            </p>
            <div className="form-group">
              <label>Personal Access Token</label>
              <input
                type="password"
                className="form-control"
                value={tokenInput}
                onChange={(e) => { setTokenInput(e.target.value); setTokenVerified(null); }}
                placeholder="glpat-..."
              />
              <button className="btn btn-outline" onClick={handleVerifyToken} disabled={!tokenInput.trim() || actionLoading}>
                {actionLoading ? 'جاري التحقق...' : 'تحقق'}
              </button>
            </div>
            {tokenVerified && verifiedInfo && (
              <div className="gitlab-verify-success">
                <p>✓ Token صالح - {verifiedInfo.username} ({verifiedInfo.name})</p>
                <button className="btn btn-primary" onClick={handleLinkAccount}>ربط الحساب</button>
              </div>
            )}
            {tokenVerified === false && (
              <div className="gitlab-verify-error"><p>✗ Token غير صالح</p></div>
            )}
            <button className="btn btn-ghost" onClick={() => setShowLinkModal(false)}>إلغاء</button>
          </div>
        </div>
      )}

      {/* Add Member Modal */}
      {showAddMemberModal && (
        <div className="gitlab-modal-overlay" onClick={() => setShowAddMemberModal(false)}>
          <div className="gitlab-modal" onClick={(e) => e.stopPropagation()}>
            <h3>➕ إضافة عضو</h3>
            <div className="form-group">
              <label>اسم المستخدم في GitLab</label>
              <input
                type="text"
                className="form-control"
                value={newMemberUsername}
                onChange={(e) => setNewMemberUsername(e.target.value)}
                placeholder="gitlab_username"
              />
            </div>
            <div className="form-group">
              <label>مستوى الصلاحية</label>
              <select
                className="form-control"
                value={newMemberLevel}
                onChange={(e) => setNewMemberLevel(Number(e.target.value))}
              >
                <option value={10}>ضيف (Guest)</option>
                <option value={20}>مراقب (Reporter)</option>
                <option value={30}>مطور (Developer)</option>
                <option value={40}>مسؤول (Maintainer)</option>
              </select>
            </div>
            <div className="gitlab-modal-actions">
              <button className="btn btn-primary" onClick={handleAddMember} disabled={actionLoading}>
                {actionLoading ? 'جاري الإضافة...' : 'إضافة'}
              </button>
              <button className="btn btn-ghost" onClick={() => setShowAddMemberModal(false)}>إلغاء</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
