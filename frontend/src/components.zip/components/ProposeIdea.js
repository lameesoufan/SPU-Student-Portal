import React, { useState, useEffect } from 'react';
import { submitStudentProposal, fetchMyProposal, fetchDoctorsList, fetchStudentForm } from '../api';
import StudentSearch from './StudentSearch';
import DynamicCheckboxGroup from './DynamicCheckboxGroup';
import './ProposeIdea.css';

const DEPARTMENTS = [
  { value: 'software_engineering',    label: 'Software Engineering' },
  { value: 'artificial_intelligence', label: 'Artificial Intelligence' },
  { value: 'information_security',    label: 'Information Security' },
  { value: 'communications',          label: 'Communications' },
  { value: 'control_robotics',        label: 'Control & Robotics' },
];

/* ── Icon Components ── */
const Icon = {
  ArrowLeft: ({ size = 18 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
  ),
  Send: ({ size = 18 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
  ),
  Users: ({ size = 18 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
  ),
  Clock: ({ size = 18 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
  ),
  Refresh: ({ size = 18 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>
  ),
  CheckCircle: ({ size = 18 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
  ),
  XCircle: ({ size = 18 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
  ),
  Info: ({ size = 18 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
  ),
  Lightbulb: ({ size = 20 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 18h6"/><path d="M10 22h4"/><path d="M12 2A7 7 0 0 0 5 9c0 2.38 1.19 4.47 3 5.74V17a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-2.26c1.81-1.27 3-3.36 3-5.74a7 7 0 0 0-7-7z"/></svg>
  ),
  UserPlus: ({ size = 20 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/></svg>
  ),
  Building: ({ size = 20 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="2" width="16" height="20" rx="2" ry="2"/><path d="M9 22v-4h6v4"/><path d="M8 6h.01"/><path d="M16 6h.01"/><path d="M12 6h.01"/><path d="M12 10h.01"/><path d="M12 14h.01"/><path d="M16 10h.01"/><path d="M16 14h.01"/><path d="M8 10h.01"/><path d="M8 14h.01"/></svg>
  ),
  Clipboard: ({ size = 20 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1" ry="1"/></svg>
  ),
  ChevronRight: ({ size = 16 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
  ),
  ChevronLeft: ({ size = 16 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
  ),
  Loader: ({ size = 18 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="pi-spin"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
  ),
  User: ({ size = 32 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
  ),
  Check: ({ size = 14 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
  ),
  Sun: ({ size = 16 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
  ),
  Moon: ({ size = 16 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
  ),
};

const STATUS_META = {
  awaiting_members:   { label: 'Awaiting Members', icon: Icon.Users, cls: 'pi-badge--amber' },
  pending_supervisor: { label: 'Pending Supervisor', icon: Icon.Clock, cls: 'pi-badge--blue' },
  pending_hod:        { label: 'Pending HoD Review', icon: Icon.Refresh, cls: 'pi-badge--purple' },
  assigned:           { label: 'Approved & Assigned', icon: Icon.CheckCircle, cls: 'pi-badge--green' },
  rejected:           { label: 'Rejected', icon: Icon.XCircle, cls: 'pi-badge--red' },
};

const STATUS_STEPS = {
  awaiting_members:   1,
  pending_supervisor: 2,
  pending_hod:        3,
  assigned:           4,
  rejected:           0,
};

const EMPTY = { title: '', description: '', department: '', supervisor: '', team_size: 2, member_ids: [''] };
const emptyValueForField = (field) => field.field_type === 'checkbox' ? [] : '';

/* ── Step Configuration ── */
const STEPS = [
  { id: 'idea',     label: 'Project Idea',    icon: Icon.Lightbulb },
  { id: 'dept',     label: 'Department',      icon: Icon.Building },
  { id: 'team',     label: 'Team',            icon: Icon.UserPlus },
  { id: 'dynamic',  label: 'Requirements',    icon: Icon.Clipboard },
];

/* ── Theme helper ── */
const THEME_KEY = 'pi-theme';
const getInitialTheme = () => {
  try {
    const saved = localStorage.getItem(THEME_KEY);
    if (saved === 'light' || saved === 'dark') return saved;
  } catch {}
  return 'dark';
};

export default function ProposeIdea({ onBack }) {
  const [theme, setTheme]           = useState(getInitialTheme);
  const [existing, setExisting]     = useState(undefined);
  const [doctors, setDoctors]       = useState([]);
  const [form, setForm]             = useState(EMPTY);
  const [loading, setLoading]       = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError]           = useState('');
  const [currentStep, setCurrentStep] = useState(0);
  const [stepAnim, setStepAnim]     = useState('');

  const toggleTheme = () => {
    setTheme(prev => {
      const next = prev === 'dark' ? 'light' : 'dark';
      try { localStorage.setItem(THEME_KEY, next); } catch {}
      return next;
    });
  };

  // Dynamic form state
  const [dynForm, setDynForm]       = useState(null);
  const [dynValues, setDynValues]   = useState({});

  useEffect(() => {
    setLoading(true);
    Promise.allSettled([fetchMyProposal(), fetchDoctorsList()])
      .then(([propRes, docRes]) => {
        if (propRes.status === 'fulfilled') {
          setExisting(propRes.value.data || null);
        } else {
          console.error('Failed to fetch proposal:', propRes.reason);
          setExisting(null);
        }

        if (docRes.status === 'fulfilled') {
          const data = docRes.value.data;
          setDoctors(Array.isArray(data) ? data : []);
          if (!Array.isArray(data) || data.length === 0) {
            console.warn('Doctors list is empty.');
          }
        } else {
          console.error('Failed to fetch doctors:', docRes.reason);
          setDoctors([]);
          setError('Could not load supervisors list. Please refresh the page.');
        }
      })
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (!form.department) { setDynForm(null); return; }
    fetchStudentForm(form.department, 'propose')
      .then(res => {
        setDynForm(res.data?.fields?.length ? res.data : null);
        const init = {};
        (res.data?.fields || []).forEach(f => { init[f.id] = emptyValueForField(f); });
        setDynValues(init);
      })
      .catch(() => setDynForm(null));
  }, [form.department]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleTeamSizeChange = (size) => {
    const s = Number(size);
    const memberCount = s - 1;
    setForm((prev) => ({
      ...prev,
      team_size: s,
      member_ids: Array(memberCount).fill(''),
    }));
  };

  const handleMemberChange = (idx, val) => {
    setForm((prev) => {
      const ids = [...prev.member_ids];
      ids[idx] = val;
      return { ...prev, member_ids: ids };
    });
  };

  /* ── Step Navigation ── */
  const hasDynamicFields = dynForm && (dynForm.fields || []).length > 0;
  const totalSteps = hasDynamicFields ? 4 : 3;

  const goNext = () => {
    if (currentStep < totalSteps - 1) {
      setStepAnim('forward');
      setCurrentStep(prev => prev + 1);
      setTimeout(() => setStepAnim(''), 400);
    }
  };

  const goPrev = () => {
    if (currentStep > 0) {
      setStepAnim('backward');
      setCurrentStep(prev => prev - 1);
      setTimeout(() => setStepAnim(''), 400);
    }
  };

  const goToStep = (idx) => {
    if (idx < currentStep) {
      setStepAnim('backward');
      setCurrentStep(idx);
    } else if (idx > currentStep) {
      setStepAnim('forward');
      setCurrentStep(idx);
    }
    setTimeout(() => setStepAnim(''), 400);
  };

  /* ── Validation per step ── */
  const isStepValid = (step) => {
    if (step === 0) return form.title.trim() !== '' && form.description.trim() !== '';
    if (step === 1) return form.department !== '' && form.supervisor !== '';
    if (step === 2) return true;
    if (step === 3) return true;
    return false;
  };

  /* ── Submit ── */
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      const res = await submitStudentProposal({
        title:            form.title,
        description:      form.description,
        department:       form.department,
        supervisor:       Number(form.supervisor),
        team_size:        Number(form.team_size),
        member_ids:       form.member_ids.filter(Boolean),
        form_id:          dynForm?.id || null,
        field_responses:  dynForm
          ? (dynForm.fields || []).map(f => ({ field: f.id, value: dynValues[f.id] ?? emptyValueForField(f) }))
          : [],
      });
      setExisting(res.data.proposal);
    } catch (err) {
      const data = err.response?.data;
      if (data?.error) setError(data.error);
      else if (data && typeof data === 'object') setError(Object.values(data).flat().join(' '));
      else setError('Something went wrong. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  /* ── Theme toggle button (reused across states) ── */
  const ThemeToggle = (
    <button className="pi-theme-toggle" onClick={toggleTheme} type="button" aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}>
      {theme === 'dark' ? <Icon.Sun size={14} /> : <Icon.Moon size={14} />}
      <span className="pi-theme-toggle-label">{theme === 'dark' ? 'Light' : 'Dark'}</span>
    </button>
  );

  /* ── Loading State ── */
  if (loading) {
    return (
      <div className="pi-page" data-theme={theme}>
        <div className="pi-loading">
          <div className="pi-loading-spinner" />
          <span>Loading proposal data…</span>
        </div>
      </div>
    );
  }

  /* ── Existing Proposal Status ── */
  if (existing) {
    const meta = STATUS_META[existing.status] || STATUS_META.pending_supervisor;
    const StatusIcon = meta.icon;
    const stepProgress = STATUS_STEPS[existing.status] || 0;
    const isRejected = existing.status === 'rejected';
    const isApproved = existing.status === 'assigned';

    return (
      <div className="pi-page" data-theme={theme}>
        {/* Header */}
        <div className="pi-header">
          <div className="pi-header-row">
            <div className="pi-header-left">
              <button className="pi-back-btn" onClick={onBack}>
                <Icon.ArrowLeft size={16} />
                <span>Back to Overview</span>
              </button>
              <h1 className="pi-title">Your Proposal</h1>
              <p className="pi-subtitle">Track your submitted project proposal status</p>
            </div>
            {ThemeToggle}
          </div>
        </div>

        {/* Status Card */}
        <div className={`pi-status-card ${isRejected ? 'pi-status-card--rejected' : ''} ${isApproved ? 'pi-status-card--approved' : ''}`}>
          <div className="pi-status-top">
            <h3 className="pi-status-proposal-title">{existing.title}</h3>
            <span className={`pi-badge ${meta.cls}`}>
              <StatusIcon size={14} />
              <span>{meta.label}</span>
            </span>
          </div>

          <p className="pi-status-desc">{existing.description}</p>

          {!isRejected && (
            <div className="pi-status-progress">
              <div className="pi-progress-track">
                {['Members', 'Supervisor', 'HoD', 'Approved'].map((label, i) => (
                  <div key={label} className={`pi-progress-step ${i + 1 <= stepProgress ? 'pi-progress-step--done' : ''}`}>
                    <div className="pi-progress-dot">
                      {i + 1 <= stepProgress ? <Icon.Check size={12} /> : <span>{i + 1}</span>}
                    </div>
                    <span className="pi-progress-label">{label}</span>
                  </div>
                ))}
                <div className="pi-progress-line" style={{ width: `${(stepProgress / 4) * 100}%` }} />
              </div>
            </div>
          )}

          <div className="pi-status-meta">
            <div className="pi-meta-item">
              <span className="pi-meta-label">Department</span>
              <span className="pi-meta-value">{existing.department.replace(/_/g, ' ')}</span>
            </div>
            <div className="pi-meta-item">
              <span className="pi-meta-label">Supervisor</span>
              <span className="pi-meta-value">{existing.supervisor_name || '—'}</span>
            </div>
            <div className="pi-meta-item">
              <span className="pi-meta-label">Team Size</span>
              <span className="pi-meta-value">{existing.team_size} student{existing.team_size > 1 ? 's' : ''}</span>
            </div>
            <div className="pi-meta-item">
              <span className="pi-meta-label">Submitted</span>
              <span className="pi-meta-value">{new Date(existing.created_at).toLocaleDateString()}</span>
            </div>
          </div>

          {existing.invitations && existing.invitations.length > 0 && (
            <div className="pi-status-members">
              <span className="pi-meta-label" style={{ marginBottom: 12 }}>Team Members</span>
              {existing.invitations.map((inv) => {
                const invIcon = inv.status === 'accepted' ? Icon.CheckCircle : inv.status === 'rejected' ? Icon.XCircle : Icon.Clock;
                const InvIcon = invIcon;
                const invCls = inv.status === 'accepted' ? 'pi-badge--green' : inv.status === 'rejected' ? 'pi-badge--red' : 'pi-badge--blue';
                return (
                  <div key={inv.id} className="pi-member-row">
                    <div className="pi-member-avatar">
                      <Icon.User size={18} />
                    </div>
                    <span className="pi-member-name">{inv.invitee_name}</span>
                    <span className="pi-member-id">{inv.invitee_id}</span>
                    <span className={`pi-badge pi-badge--sm ${invCls}`}>
                      <InvIcon size={12} />
                      {inv.status.charAt(0).toUpperCase() + inv.status.slice(1)}
                    </span>
                  </div>
                );
              })}
            </div>
          )}

          {existing.status === 'awaiting_members' && (
            <div className="pi-alert pi-alert--info">
              <Icon.Info size={16} />
              <span>Waiting for team members to confirm their participation.</span>
            </div>
          )}
          {existing.status === 'assigned' && (
            <div className="pi-alert pi-alert--success">
              <Icon.CheckCircle size={16} />
              <span>Your idea has been approved and assigned to you. Go to "My Project" to start working!</span>
            </div>
          )}
          {existing.status === 'rejected' && existing.rejection_reason && (
            <div className="pi-alert pi-alert--error">
              <Icon.XCircle size={16} />
              <span><strong>Rejection reason:</strong> {existing.rejection_reason}</span>
            </div>
          )}
          {existing.status === 'pending_supervisor' && (
            <div className="pi-alert pi-alert--info">
              <Icon.Info size={16} />
              <span>Waiting for <strong>{existing.supervisor_name}</strong> to review your proposal.</span>
            </div>
          )}
          {existing.status === 'pending_hod' && (
            <div className="pi-alert pi-alert--info">
              <Icon.Info size={16} />
              <span>Approved by supervisor — now awaiting HoD review.</span>
            </div>
          )}
        </div>
      </div>
    );
  }

  /* ── New Proposal Form ── */
  return (
    <div className="pi-page" data-theme={theme}>
      {/* Header */}
      <div className="pi-header">
        <div className="pi-header-row">
          <div className="pi-header-left">
            <button className="pi-back-btn" onClick={onBack}>
              <Icon.ArrowLeft size={16} />
              <span>Back to Overview</span>
            </button>
            <h1 className="pi-title">Project Proposal</h1>
            <p className="pi-subtitle">Submit a new idea for approval — fill in each step below</p>
          </div>
          {ThemeToggle}
        </div>
      </div>

      {/* Step Indicator */}
      <div className="pi-stepper">
        {STEPS.slice(0, totalSteps).map((step, i) => {
          const StepIcon = step.icon;
          const isActive = i === currentStep;
          const isDone = i < currentStep;
          return (
            <button
              key={step.id}
              className={`pi-step ${isActive ? 'pi-step--active' : ''} ${isDone ? 'pi-step--done' : ''}`}
              onClick={() => isDone && goToStep(i)}
              type="button"
            >
              <div className="pi-step-dot">
                {isDone ? <Icon.Check size={14} /> : <StepIcon size={16} />}
              </div>
              <span className="pi-step-label">{step.label}</span>
              {i < totalSteps - 1 && <div className="pi-step-line" />}
            </button>
          );
        })}
      </div>

      {/* Form Card */}
      <div className="pi-form-card">
        {error && (
          <div className="pi-alert pi-alert--error" style={{ marginBottom: 24 }}>
            <Icon.XCircle size={16} />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} noValidate>
          <div className={`pi-step-content ${stepAnim === 'forward' ? 'pi-slide-forward' : ''} ${stepAnim === 'backward' ? 'pi-slide-backward' : ''}`}>
            {/* Step 0: Project Idea */}
            {currentStep === 0 && (
              <div className="pi-step-panel">
                <div className="pi-step-panel-header">
                  <Icon.Lightbulb size={24} />
                  <div>
                    <h2>Project Idea</h2>
                    <p>Describe your graduation project concept and objectives</p>
                  </div>
                </div>
                <div className="pi-field">
                  <label htmlFor="p-title">Project Title <span className="pi-required">*</span></label>
                  <input id="p-title" name="title" type="text" className="pi-input"
                    value={form.title} onChange={handleChange}
                    placeholder="e.g. Smart Campus Navigation App" required autoFocus />
                  <span className="pi-field-hint">Choose a clear, descriptive title for your project</span>
                </div>
                <div className="pi-field">
                  <label htmlFor="p-desc">Project Description <span className="pi-required">*</span></label>
                  <textarea id="p-desc" name="description" rows={5} className="pi-input pi-textarea"
                    value={form.description} onChange={handleChange}
                    placeholder="Describe your project idea in detail — goals, methodology, expected outcomes, and technologies you plan to use…" required />
                  <span className="pi-field-hint">Be specific: include objectives, methodology, and expected deliverables</span>
                </div>
              </div>
            )}

            {/* Step 1: Department & Supervisor */}
            {currentStep === 1 && (
              <div className="pi-step-panel">
                <div className="pi-step-panel-header">
                  <Icon.Building size={24} />
                  <div>
                    <h2>Department & Supervisor</h2>
                    <p>Select your department and preferred supervisor</p>
                  </div>
                </div>
                <div className="pi-field-grid">
                  <div className="pi-field">
                    <label htmlFor="p-dept">Department <span className="pi-required">*</span></label>
                    <div className="pi-select-wrap">
                      <select id="p-dept" name="department" className="pi-input"
                        value={form.department} onChange={handleChange} required>
                        <option value="">Select Department</option>
                        {DEPARTMENTS.map((d) => (
                          <option key={d.value} value={d.value}>{d.label}</option>
                        ))}
                      </select>
                      <Icon.ChevronRight size={16} />
                    </div>
                  </div>
                  <div className="pi-field">
                    <label htmlFor="p-sup">Preferred Supervisor <span className="pi-required">*</span></label>
                    <div className="pi-select-wrap">
                      <select id="p-sup" name="supervisor" className="pi-input"
                        value={form.supervisor} onChange={handleChange}
                        required disabled={doctors.length === 0}>
                        <option value="">
                          {doctors.length === 0 ? 'No supervisors available' : 'Select Supervisor'}
                        </option>
                        {doctors.map((d) => (
                          <option key={d.id} value={d.id}>
                            {d.name}{d.department ? ` (${d.department.replace(/_/g, ' ')})` : ''}
                          </option>
                        ))}
                      </select>
                      <Icon.ChevronRight size={16} />
                    </div>
                    {doctors.length === 0 && (
                      <span className="pi-field-hint" style={{ color: 'var(--pi-warning)', marginTop: 8 }}>
                        No doctors found in the system. Please contact your department or try refreshing.
                      </span>
                    )}
                  </div>
                </div>
                <div className="pi-info-card">
                  <Icon.Info size={16} />
                  <span>The supervisor you select will review and approve your proposal before it goes to the Head of Department.</span>
                </div>
              </div>
            )}

            {/* Step 2: Team */}
            {currentStep === 2 && (
              <div className="pi-step-panel">
                <div className="pi-step-panel-header">
                  <Icon.UserPlus size={24} />
                  <div>
                    <h2>Team Setup</h2>
                    <p>Choose your team size and invite members</p>
                  </div>
                </div>
                <div className="pi-field" style={{ maxWidth: 280 }}>
                  <label>Team Size</label>
                  <div className="pi-team-size-selector">
                    {[2, 3].map((n) => (
                      <button key={n} type="button"
                        className={`pi-size-btn ${form.team_size === n ? 'pi-size-btn--active' : ''}`}
                        onClick={() => handleTeamSizeChange(n)}>
                        <span className="pi-size-num">{n}</span>
                        <span className="pi-size-label">{n === 1 ? 'Solo' : 'Members'}</span>
                      </button>
                    ))}
                  </div>
                </div>
                {form.member_ids.map((val, idx) => (
                  <div className="pi-field" key={idx}>
                    <label htmlFor={`p-member-${idx}`}>
                      <span className="pi-member-label">Team Member {idx + 2}</span>
                      <span className="pi-field-hint" style={{ marginLeft: 8 }}>Search by name or university ID</span>
                    </label>
                    <StudentSearch
                      id={`p-member-${idx}`}
                      value={val}
                      onChange={(username) => handleMemberChange(idx, username)}
                      placeholder="Type to search students…"
                    />
                  </div>
                ))}
                <div className="pi-info-card">
                  <Icon.Info size={16} />
                  <span>Team size is <strong>2–3 students</strong>. You are automatically included as the team leader.</span>
                </div>
              </div>
            )}

            {/* Step 3: Dynamic Fields */}
            {currentStep === 3 && hasDynamicFields && (
              <div className="pi-step-panel">
                <div className="pi-step-panel-header">
                  <Icon.Clipboard size={24} />
                  <div>
                    <h2>{dynForm.title || 'Department Requirements'}</h2>
                    <p>{dynForm.description || 'Fill in the additional fields required by your department'}</p>
                  </div>
                </div>
                {(dynForm.fields || []).map(field => (
                  <ProposeDynField key={field.id} field={field}
                    value={dynValues[field.id] ?? emptyValueForField(field)}
                    onChange={val => setDynValues(prev => ({ ...prev, [field.id]: val }))} />
                ))}
              </div>
            )}

            {/* Step 3 (no dynamic): Review */}
            {currentStep === 3 && !hasDynamicFields && (
              <div className="pi-step-panel">
                <div className="pi-step-panel-header">
                  <Icon.Clipboard size={24} />
                  <div>
                    <h2>Review & Submit</h2>
                    <p>Review your proposal details before submitting</p>
                  </div>
                </div>
                <div className="pi-review-grid">
                  <div className="pi-review-item">
                    <span className="pi-review-label">Title</span>
                    <span className="pi-review-value">{form.title || '—'}</span>
                  </div>
                  <div className="pi-review-item">
                    <span className="pi-review-label">Department</span>
                    <span className="pi-review-value">{DEPARTMENTS.find(d => d.value === form.department)?.label || '—'}</span>
                  </div>
                  <div className="pi-review-item">
                    <span className="pi-review-label">Supervisor</span>
                    <span className="pi-review-value">{doctors.find(d => d.id === Number(form.supervisor))?.name || '—'}</span>
                  </div>
                  <div className="pi-review-item">
                    <span className="pi-review-label">Team Size</span>
                    <span className="pi-review-value">{form.team_size} students</span>
                  </div>
                </div>
                <div className="pi-review-desc">
                  <span className="pi-review-label">Description</span>
                  <p>{form.description || '—'}</p>
                </div>
              </div>
            )}
          </div>

          {/* Navigation Buttons */}
          <div className="pi-nav-bar">
            {currentStep > 0 ? (
              <button type="button" className="pi-nav-btn pi-nav-btn--prev" onClick={goPrev}>
                <Icon.ChevronLeft size={16} />
                <span>Previous</span>
              </button>
            ) : <div />}
            {currentStep < totalSteps - 1 ? (
              <button type="button" className="pi-nav-btn pi-nav-btn--next"
                onClick={goNext} disabled={!isStepValid(currentStep)}>
                <span>Continue</span>
                <Icon.ChevronRight size={16} />
              </button>
            ) : (
              <button type="submit" className="pi-nav-btn pi-nav-btn--submit" disabled={submitting}>
                {submitting ? (
                  <><Icon.Loader size={16} /><span>Submitting…</span></>
                ) : (
                  <><Icon.Send size={16} /><span>Submit Proposal</span></>
                )}
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}

/* ── Dynamic Field Renderer ── */
function ProposeDynField({ field, value, onChange }) {
  const { label, field_type, required, options } = field;
  return (
    <div className="pi-field">
      <label className="pi-dyn-label">
        {label}
        {required && <span className="pi-required"> *</span>}
      </label>
      {field_type === 'text' && (
        <input className="pi-input" type="text" value={value} required={required}
          onChange={e => onChange(e.target.value)} />
      )}
      {field_type === 'textarea' && (
        <textarea className="pi-input pi-textarea" rows={3} value={value} required={required}
          onChange={e => onChange(e.target.value)} />
      )}
      {field_type === 'number' && (
        <input className="pi-input" type="number" value={value} required={required}
          min="0" step="any" onChange={e => onChange(e.target.value)} style={{ maxWidth: 160 }} />
      )}
      {field_type === 'date' && (
        <input className="pi-input" type="date" value={value} required={required}
          onChange={e => onChange(e.target.value)} />
      )}
      {field_type === 'select' && (
        <div className="pi-select-wrap">
          <select className="pi-input" value={value} required={required}
            onChange={e => onChange(e.target.value)}>
            <option value="">Select…</option>
            {(options || []).map(o => <option key={o} value={o}>{o}</option>)}
          </select>
          <Icon.ChevronRight size={16} />
        </div>
      )}
      {field_type === 'radio' && (
        <div className="pi-radio-group">
          {(options || []).map(o => (
            <label key={o} className={`pi-radio-item ${value === o ? 'pi-radio-item--selected' : ''}`}>
              <input type="radio" name={`dyn-${field.id}`} value={o}
                checked={value === o} onChange={() => onChange(o)} required={required} />
              <span className="pi-radio-dot" />
              <span>{o}</span>
            </label>
          ))}
        </div>
      )}
      {field_type === 'checkbox' && (
        <DynamicCheckboxGroup field={field} value={value} onChange={onChange} />
      )}
      {field_type === 'file' && (
        <div className="pi-file-input">
          <input className="pi-input" type="file" required={required}
            accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.gif"
            onChange={e => { const f = e.target.files?.[0]; if (f) onChange(f.name); }} />
          <span className="pi-field-hint">Accepted: PDF, DOC, DOCX, JPG, PNG</span>
        </div>
      )}
    </div>
  );
}