import React, { useState, useEffect } from 'react';
import { fetchHodPending, hodReview, fetchResponseByProposal } from '../api';
import './HodProposalReview.css';

const renderResponseValue = (value) => {
  if (Array.isArray(value)) return value.length
    ? <div className="hod-proposal-choice-pills">{value.map((item) => <span key={item} className="hod-proposal-choice-pill">{item}</span>)}</div>
    : null;
  return value || null;
};

export default function HodProposalReview({ onBack }) {
  const [proposals, setProposals]     = useState([]);
  const [loading, setLoading]         = useState(true);
  const [error, setError]             = useState('');
  const [reviewing, setReviewing]     = useState(null);
  const [reason, setReason]           = useState('');
  const [actionError, setActionError] = useState('');
  const [confirming, setConfirming]   = useState(false);
  const [formResponses, setFormResponses] = useState({});
  const [expandedForm, setExpandedForm]   = useState(null);

  useEffect(() => {
    let active = true;
    fetchHodPending()
      .then(async (res) => {
        if (!active) return;
        setProposals(res.data);
        const responses = await Promise.allSettled(
          res.data.map((p) => fetchResponseByProposal(p.id).then((r) => [p.id, r.data]))
        );
        if (!active) return;
        const next = {};
        responses.forEach((result) => {
          if (result.status === 'fulfilled') next[result.value[0]] = result.value[1];
        });
        setFormResponses(next);
      })
      .catch(() => { if (active) setError('Failed to load proposals.'); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);

  const openReview = (id, action) => {
    setReviewing({ id, action });
    setReason('');
    setActionError('');
  };

  const handleConfirm = async () => {
    if (!reviewing || confirming) return;
    setActionError('');
    setConfirming(true);
    try {
      await hodReview(reviewing.id, {
        action: reviewing.action,
        rejection_reason: reason,
      });
      setProposals((prev) => prev.filter((p) => p.id !== reviewing.id));
      setReviewing(null);
    } catch (err) {
      const data = err.response?.data;
      if (data?.rejection_reason) setActionError(data.rejection_reason[0]);
      else if (data?.error) setActionError(data.error);
      else setActionError('Something went wrong.');
    } finally {
      setConfirming(false);
    }
  };

  return (
    <div className="hod-proposal-review">
      {/* Page Header */}
      <div className="hod-proposal-header">
        <button className="back-btn" onClick={onBack}>← Back</button>
        <div className="hod-proposal-header-info">
          <h1>Student Proposals</h1>
          <p>Review and approve project proposals from students</p>
        </div>
        {proposals.length > 0 && (
          <div className="hod-proposal-header-count">{proposals.length}</div>
        )}
      </div>

      {error && <div className="alert alert-error">{error}</div>}

      {loading && (
        <div className="hod-proposal-loading">
          <div className="spinner spinner-dark"></div>
          Loading proposals…
        </div>
      )}

      {!loading && proposals.length === 0 && !error && (
        <div className="empty-state">
          <div className="empty-state-icon">📋</div>
          <h3>All caught up</h3>
          <p>No proposals pending your review. New submissions will appear here.</p>
        </div>
      )}

      <div className="hod-proposal-list">
        {proposals.map((p) => {
          const resp = formResponses[p.id];
          const isExpanded = expandedForm === p.id;

          return (
            <div key={p.id} className="hod-proposal-card">
              <div className="hod-proposal-card-header">
                <div className="hod-proposal-card-title-group">
                  <h3 className="hod-proposal-card-title">{p.title}</h3>
                  <span className="hod-proposal-card-author">
                    <span className="hod-proposal-card-author-icon">S</span>
                    {p.student_name}
                  </span>
                </div>
                <div className="hod-proposal-card-meta">
                  <span className="badge badge-primary">{p.department.replace(/_/g, ' ')}</span>
                  <span className="badge badge-neutral">{p.supervisor_name}</span>
                </div>
              </div>

              <div className="hod-proposal-card-body">
                <p className="hod-proposal-card-desc">{p.description}</p>

                {/* Team members */}
                {p.invitations && p.invitations.length > 0 && (
                  <div className="hod-proposal-team">
                    <span className="hod-proposal-team-label">Team:</span>
                    {p.invitations.map((inv) => (
                      <span key={inv.id} className={`hod-proposal-team-member hod-proposal-team-member--${inv.status}`}>
                        {inv.invitee_name}
                      </span>
                    ))}
                  </div>
                )}

                {/* Dynamic form responses */}
                {resp && resp.field_responses && resp.field_responses.length > 0 && (
                  <div className="hod-proposal-form-section">
                    <button
                      className="hod-proposal-form-toggle"
                      onClick={() => setExpandedForm(isExpanded ? null : p.id)}
                      aria-expanded={isExpanded}
                    >
                      Department Form Responses
                      <span className="hod-proposal-form-toggle-arrow">▼</span>
                    </button>
                    {isExpanded && (
                      <div className="hod-proposal-form-responses">
                        {resp.field_responses.map((fr, idx) => (
                          <div key={idx} className="hod-proposal-form-field">
                            <span className="hod-proposal-form-field-label">{fr.field_label}</span>
                            <span className="hod-proposal-form-field-value">
                              {renderResponseValue(fr.value) || <em className="hod-proposal-form-empty">—</em>}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="hod-proposal-card-footer">
                <button className="btn btn-primary" onClick={() => openReview(p.id, 'approve')}>
                  Approve &amp; Assign
                </button>
                <button className="btn btn-danger" onClick={() => openReview(p.id, 'reject')}>
                  Reject
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {reviewing && (
        <div className="hod-proposal-modal-overlay" role="dialog" aria-modal="true">
          <div className="hod-proposal-modal">
            <div className="hod-proposal-modal-header">
              <div className={`hod-proposal-modal-icon hod-proposal-modal-icon--${reviewing.action}`}>
                {reviewing.action === 'approve' ? '✓' : '✕'}
              </div>
              <h3>
                {reviewing.action === 'approve' ? 'Approve & Assign' : 'Reject Proposal'}
              </h3>
            </div>

            {reviewing.action === 'approve' && (
              <p className="hod-proposal-modal-note">
                Approving will assign this project to the student and automatically create a project application with status <strong>Accepted</strong>.
              </p>
            )}

            {reviewing.action === 'reject' && (
              <div className="hod-proposal-modal-form form-group">
                <label htmlFor="hod-reason">
                  Rejection Reason <span style={{ color: 'var(--danger)' }}>*</span>
                </label>
                <textarea
                  id="hod-reason"
                  className="form-control"
                  rows={3}
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="Explain why this proposal is being rejected…"
                />
              </div>
            )}

            {actionError && <div className="alert alert-error">{actionError}</div>}

            <div className="hod-proposal-modal-actions">
              <button className="btn btn-outline" onClick={() => setReviewing(null)} disabled={confirming}>
                Cancel
              </button>
              <button
                className={`btn ${reviewing.action === 'approve' ? 'btn-primary' : 'btn-danger'}`}
                onClick={handleConfirm}
                disabled={confirming}
              >
                {confirming ? 'Processing…' : 'Confirm'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
