import React, { useState, useEffect } from 'react';
import { fetchHodPendingApplications, hodReviewApplication, fetchResponseByApplication } from '../api';
import './HodApplicationReview.css';

const renderResponseValue = (value) => {
  if (Array.isArray(value)) return value.length
    ? <div className="hod-app-choice-pills">{value.map((item) => <span key={item} className="hod-app-choice-pill">{item}</span>)}</div>
    : null;
  return value || null;
};

export default function HodApplicationReview({ onBack }) {
  const [apps, setApps]           = useState([]);
  const [loading, setLoading]     = useState(true);
  const [error, setError]         = useState('');
  const [reviewing, setReviewing] = useState(null);
  const [reason, setReason]       = useState('');
  const [actionError, setActionError] = useState('');
  const [confirming, setConfirming]   = useState(false);
  const [formResponses, setFormResponses] = useState({});
  const [expandedForm, setExpandedForm]   = useState(null);

  useEffect(() => {
    let active = true;
    fetchHodPendingApplications()
      .then(async (res) => {
        if (!active) return;
        setApps(res.data);
        const responses = await Promise.allSettled(
          res.data.map((app) => fetchResponseByApplication(app.id).then((r) => [app.id, r.data]))
        );
        if (!active) return;
        const next = {};
        responses.forEach((result) => {
          if (result.status === 'fulfilled') next[result.value[0]] = result.value[1];
        });
        setFormResponses(next);
      })
      .catch(() => { if (active) setError('Failed to load applications.'); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);

  const openReview = (id, action) => { setReviewing({ id, action }); setReason(''); setActionError(''); };

  const handleConfirm = async () => {
    if (!reviewing || confirming) return;
    setActionError('');
    setConfirming(true);
    try {
      await hodReviewApplication(reviewing.id, { action: reviewing.action, rejection_reason: reason });
      setApps((prev) => prev.filter((a) => a.id !== reviewing.id));
      setReviewing(null);
    } catch (err) {
      const data = err.response?.data;
      setActionError(data?.rejection_reason?.[0] || data?.error || 'Something went wrong.');
    } finally {
      setConfirming(false);
    }
  };

  return (
    <div className="hod-app-review">
      {/* Page Header */}
      <div className="hod-app-header">
        <button className="back-btn" onClick={onBack}>← Back</button>
        <div className="hod-app-header-info">
          <h1>Student Applications</h1>
          <p>Review and register project applications submitted by students</p>
        </div>
        {apps.length > 0 && (
          <div className="hod-app-header-count">{apps.length}</div>
        )}
      </div>

      {error && <div className="alert alert-error">{error}</div>}

      {loading && (
        <div className="hod-app-loading">
          <div className="spinner spinner-dark"></div>
          Loading applications…
        </div>
      )}

      {!loading && apps.length === 0 && !error && (
        <div className="empty-state">
          <div className="empty-state-icon">📋</div>
          <h3>All caught up</h3>
          <p>No pending applications. New submissions will appear here for your review.</p>
        </div>
      )}

      <div className="hod-app-list">
        {apps.map((app) => {
          const resp = formResponses[app.id];
          const isExpanded = expandedForm === app.id;

          return (
            <div key={app.id} className="hod-app-card">
              <div className="hod-app-card-header">
                <div className="hod-app-card-title-group">
                  <h3 className="hod-app-card-title">{app.idea_title}</h3>
                  <span className="hod-app-card-author">
                    <span className="hod-app-card-author-icon">S</span>
                    {app.student_name}
                  </span>
                </div>
                <div className="hod-app-card-meta">
                  <span className="badge badge-neutral">{app.doctor_name}</span>
                  <span className="badge badge-primary">{app.team_size} student{app.team_size > 1 ? 's' : ''}</span>
                  <span className="badge badge-neutral">{new Date(app.created_at).toLocaleDateString()}</span>
                </div>
              </div>

              <div className="hod-app-card-body">
                {/* Team members */}
                {app.invitations && app.invitations.length > 0 && (
                  <div className="hod-app-team">
                    <span className="hod-app-team-label">Team:</span>
                    {app.invitations.map((inv) => (
                      <span key={inv.id} className={`hod-app-team-member hod-app-team-member--${inv.status}`}>
                        {inv.invitee_name}
                      </span>
                    ))}
                  </div>
                )}

                {/* Dynamic form responses */}
                {resp && resp.field_responses && resp.field_responses.length > 0 && (
                  <div className="hod-app-form-section">
                    <button
                      className="hod-app-form-toggle"
                      onClick={() => setExpandedForm(isExpanded ? null : app.id)}
                      aria-expanded={isExpanded}
                    >
                      Department Form Responses
                      <span className="hod-app-form-toggle-arrow">▼</span>
                    </button>
                    {isExpanded && (
                      <div className="hod-app-form-responses">
                        {resp.field_responses.map((fr, idx) => (
                          <div key={idx} className="hod-app-form-field">
                            <span className="hod-app-form-field-label">{fr.field_label}</span>
                            <span className="hod-app-form-field-value">
                              {renderResponseValue(fr.value) || <em className="hod-app-form-empty">—</em>}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="hod-app-card-footer">
                <button className="btn btn-primary" onClick={() => openReview(app.id, 'approve')}>Register Project</button>
                <button className="btn btn-danger"  onClick={() => openReview(app.id, 'reject')}>Reject</button>
              </div>
            </div>
          );
        })}
      </div>

      {reviewing && (
        <div className="hod-app-modal-overlay" role="dialog" aria-modal="true">
          <div className="hod-app-modal">
            <div className="hod-app-modal-header">
              <div className={`hod-app-modal-icon hod-app-modal-icon--${reviewing.action}`}>
                {reviewing.action === 'approve' ? '✓' : '✕'}
              </div>
              <h3>
                {reviewing.action === 'approve' ? 'Register Project' : 'Reject Application'}
              </h3>
            </div>
            {reviewing.action === 'approve' && (
              <p className="hod-app-modal-note">Approving will <strong>register</strong> this project for the student.</p>
            )}
            {reviewing.action === 'reject' && (
              <div className="hod-app-modal-form form-group">
                <label htmlFor="hod-app-reason">
                  Rejection Reason <span style={{ color: 'var(--danger)' }}>*</span>
                </label>
                <textarea id="hod-app-reason" className="form-control" rows={3}
                  value={reason} onChange={(e) => setReason(e.target.value)}
                  placeholder="Explain why this application is being rejected…" />
              </div>
            )}
            {actionError && <div className="alert alert-error">{actionError}</div>}
            <div className="hod-app-modal-actions">
              <button className="btn btn-outline" onClick={() => setReviewing(null)} disabled={confirming}>Cancel</button>
              <button className={`btn ${reviewing.action === 'approve' ? 'btn-primary' : 'btn-danger'}`} onClick={handleConfirm} disabled={confirming}>
                {confirming ? 'Processing…' : 'Confirm'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
