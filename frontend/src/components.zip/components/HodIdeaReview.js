import React, { useState, useEffect } from 'react';
import { fetchHodPendingDoctorIdeas, hodReviewDoctorIdea } from '../api';
import './HodIdeaReview.css';

export default function HodIdeaReview({ onBack }) {
  const [ideas, setIdeas]         = useState([]);
  const [loading, setLoading]     = useState(true);
  const [error, setError]         = useState('');
  const [reviewing, setReviewing] = useState(null); // { id, action }
  const [reason, setReason]       = useState('');
  const [actionError, setActionError] = useState('');
  const [confirming, setConfirming]   = useState(false);

  useEffect(() => {
    fetchHodPendingDoctorIdeas()
      .then((res) => setIdeas(res.data))
      .catch(() => setError('Failed to load ideas.'))
      .finally(() => setLoading(false));
  }, []);

  const openReview = (id, action) => {
    setReviewing({ id, action });
    setReason('');
    setActionError('');
  };

  const handleConfirm = async () => {
    if (!reviewing || confirming) return;
    setActionError('');
    setConfirming(true);
    try {
      await hodReviewDoctorIdea(reviewing.id, {
        action: reviewing.action,
        rejection_reason: reason,
      });
      setIdeas((prev) => prev.filter((i) => i.id !== reviewing.id));
      setReviewing(null);
    } catch (err) {
      const data = err.response?.data;
      if (data?.rejection_reason) setActionError(data.rejection_reason[0]);
      else if (data?.error) setActionError(data.error);
      else setActionError('Something went wrong.');
    } finally {
      setConfirming(false);
    }
  };

  return (
    <div className="hod-idea-review">
      {/* Page Header */}
      <div className="hod-idea-header">
        <button className="back-btn" onClick={onBack}>← Back</button>
        <div className="hod-idea-header-info">
          <h1>Doctor Project Ideas</h1>
          <p>Review and approve ideas submitted by doctors in your department</p>
        </div>
        {ideas.length > 0 && (
          <div className="hod-idea-header-count">{ideas.length}</div>
        )}
      </div>

      {error && <div className="alert alert-error">{error}</div>}

      {loading && (
        <div className="hod-idea-loading">
          <div className="spinner spinner-dark"></div>
          Loading ideas…
        </div>
      )}

      {!loading && ideas.length === 0 && !error && (
        <div className="empty-state">
          <div className="empty-state-icon">📋</div>
          <h3>All caught up</h3>
          <p>No pending doctor ideas at the moment. New submissions will appear here for your review.</p>
        </div>
      )}

      <div className="hod-idea-list">
        {ideas.map((idea) => (
          <div key={idea.id} className="hod-idea-card">
            <div className="hod-idea-card-header">
              <div className="hod-idea-card-title-group">
                <h3 className="hod-idea-card-title">{idea.title}</h3>
                <span className="hod-idea-card-author">
                  <span className="hod-idea-card-author-icon">D</span>
                  {idea.doctor_name}
                </span>
              </div>
              <div className="hod-idea-card-meta">
                <span className="badge badge-primary">{idea.department.replace(/_/g, ' ')}</span>
                <span className="badge badge-neutral">{idea.max_team_size} students</span>
              </div>
            </div>

            <div className="hod-idea-card-body">
              <p className="hod-idea-card-desc">{idea.description}</p>
              {idea.required_skills && (
                <div className="hod-idea-skills">
                  <span className="hod-idea-skill-label">Skills:</span>
                  {idea.required_skills.split(',').map((skill, i) => (
                    <span key={i} className="hod-idea-skill-badge">{skill.trim()}</span>
                  ))}
                </div>
              )}
            </div>

            <div className="hod-idea-card-footer">
              <button className="btn btn-primary" onClick={() => openReview(idea.id, 'approve')}>
                Approve
              </button>
              <button className="btn btn-danger" onClick={() => openReview(idea.id, 'reject')}>
                Reject
              </button>
            </div>
          </div>
        ))}
      </div>

      {reviewing && (
        <div className="hod-idea-modal-overlay" role="dialog" aria-modal="true">
          <div className="hod-idea-modal">
            <div className="hod-idea-modal-header">
              <div className={`hod-idea-modal-icon hod-idea-modal-icon--${reviewing.action}`}>
                {reviewing.action === 'approve' ? '✓' : '✕'}
              </div>
              <h3>
                {reviewing.action === 'approve' ? 'Approve Idea' : 'Reject Idea'}
              </h3>
            </div>

            {reviewing.action === 'approve' && (
              <p className="hod-idea-modal-note">
                This idea will be marked as <strong>Approved</strong> and become available for student applications.
              </p>
            )}

            {reviewing.action === 'reject' && (
              <div className="hod-idea-modal-form form-group">
                <label htmlFor="hod-idea-reason">
                  Rejection Reason <span>*</span>
                </label>
                <textarea
                  id="hod-idea-reason"
                  className="form-control"
                  rows={3}
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="Explain why this idea is being rejected…"
                />
              </div>
            )}

            {actionError && <div className="alert alert-error">{actionError}</div>}

            <div className="hod-idea-modal-actions">
              <button className="btn btn-outline" onClick={() => setReviewing(null)} disabled={confirming}>
                Cancel
              </button>
              <button
                className={`btn ${reviewing.action === 'approve' ? 'btn-primary' : 'btn-danger'}`}
                onClick={handleConfirm}
                disabled={confirming}
              >
                {confirming ? 'Processing…' : 'Confirm'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
