import React, { useState, useEffect } from 'react';
import {
  fetchMyInvitations, respondToInvitation,
  fetchMyProposalInvitations, respondToProposalInvitation,
} from '../api';

/* SVG Icons */
const Icons = {
  Inbox: <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/></svg>,
  Check: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>,
  X: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>,
  User: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>,
  Briefcase: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>,
  Info: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>,
};

const styles = {
  page: {
    width: '100%',
    display: 'flex',
    flexDirection: 'column',
    gap: 24,
  },
  sectionLabel: {
    fontSize: 13,
    color: 'var(--muted)',
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '0.5px',
    marginBottom: 12,
  },
  cardList: {
    display: 'flex',
    flexDirection: 'column',
    gap: 12,
  },
  card: {
    background: 'var(--card)',
    border: '1px solid var(--border)',
    borderRadius: 'var(--radius-lg)',
    overflow: 'hidden',
    transition: 'box-shadow var(--transition)',
  },
  cardBody: {
    padding: '20px',
  },
  cardMeta: {
    display: 'flex',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8,
  },
  cardMetaChip: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: 6,
    fontSize: 12,
    fontWeight: 500,
    color: 'var(--primary)',
    background: 'var(--primary-bg)',
    padding: '4px 10px',
    borderRadius: 20,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: 600,
    color: 'var(--text)',
    margin: '0 0 12px',
    lineHeight: 1.4,
  },
  infoRow: {
    display: 'flex',
    alignItems: 'center',
    gap: 10,
    padding: '10px 12px',
    background: 'var(--surface)',
    borderRadius: 'var(--radius)',
    marginBottom: 12,
  },
  infoIcon: {
    color: 'var(--muted)',
    flexShrink: 0,
  },
  infoLabel: {
    fontSize: 11,
    color: 'var(--muted)',
    display: 'block',
    marginBottom: 1,
    fontWeight: 500,
    textTransform: 'uppercase',
    letterSpacing: '0.03em',
  },
  infoValue: {
    fontSize: 14,
    fontWeight: 600,
    color: 'var(--text)',
  },
  noticeBar: {
    display: 'flex',
    alignItems: 'flex-start',
    gap: 10,
    padding: '12px 16px',
    background: 'var(--primary-bg)',
    borderLeft: '3px solid var(--primary)',
    fontSize: 13,
    color: 'var(--text-secondary)',
    lineHeight: 1.5,
  },
  noticeIcon: {
    color: 'var(--primary)',
    flexShrink: 0,
    marginTop: 1,
  },
  cardActions: {
    display: 'flex',
    gap: 10,
    padding: '16px 20px',
    borderTop: '1px solid var(--border-light)',
    background: 'var(--surface)',
  },
  actionBtn: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: 6,
  },
  emptyWrap: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '64px 24px',
    textAlign: 'center',
  },
  emptyIconWrap: {
    width: 64,
    height: 64,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: '50%',
    background: 'var(--surface-raised)',
    color: 'var(--muted)',
    marginBottom: 16,
  },
  loadingWrap: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '48px 24px',
    color: 'var(--muted)',
    fontSize: 14,
  },
};

export default function MyInvitations({ onBack }) {
  const [ideaInvs, setIdeaInvs]       = useState([]);
  const [propInvs, setPropInvs]       = useState([]);
  const [loading, setLoading]         = useState(true);
  const [error, setError]             = useState('');
  const [acting, setActing]           = useState(null);

  useEffect(() => {
    Promise.all([fetchMyInvitations(), fetchMyProposalInvitations()])
      .then(([ideaRes, propRes]) => {
        setIdeaInvs(ideaRes.data);
        setPropInvs(propRes.data);
      })
      .catch(() => setError('Failed to load invitations.'))
      .finally(() => setLoading(false));
  }, []);

  const handleIdeaRespond = async (invId, action) => {
    setActing(invId);
    try {
      await respondToInvitation(invId, action);
      setIdeaInvs((prev) => prev.filter((i) => i.id !== invId));
    } catch (err) {
      setError(err.response?.data?.error || 'Something went wrong.');
    } finally {
      setActing(null);
    }
  };

  const handlePropRespond = async (invId, action) => {
    setActing(invId);
    try {
      await respondToProposalInvitation(invId, action);
      setPropInvs((prev) => prev.filter((i) => i.id !== invId));
    } catch (err) {
      setError(err.response?.data?.error || 'Something went wrong.');
    } finally {
      setActing(null);
    }
  };

  const total = ideaInvs.length + propInvs.length;

  return (
    <div style={styles.page}>
      <div className="page-header">
        {onBack && (
          <button className="back-btn" onClick={onBack}>← Back</button>
        )}
        <h1 className="page-title">Team Invitations</h1>
        <p className="page-subtitle" style={{ color: 'var(--text-secondary)', fontSize: 14, marginTop: 4 }}>
          Review and respond to pending team formation requests.
        </p>
      </div>

      {error && (
        <div className="alert alert-error" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ flexShrink: 0 }}>{Icons.Info}</span>
          <span>{error}</span>
        </div>
      )}

      {loading && (
        <div style={styles.loadingWrap}>
          <div className="spinner spinner-dark"></div>
        </div>
      )}

      {!loading && total === 0 && !error && (
        <div style={styles.emptyWrap}>
          <div style={styles.emptyIconWrap}>{Icons.Inbox}</div>
          <h3 style={{ fontSize: 18, fontWeight: 600, color: 'var(--text)', margin: '0 0 8px' }}>No pending invitations</h3>
          <p style={{ fontSize: 14, color: 'var(--muted)', margin: 0 }}>You're all caught up!</p>
        </div>
      )}

      {/* Doctor idea application invitations */}
      {ideaInvs.length > 0 && (
        <div>
          <p style={styles.sectionLabel}>Doctor Idea Applications</p>
          <div style={styles.cardList}>
            {ideaInvs.map((inv) => (
              <div key={inv.id} style={styles.card}>
                <div style={styles.cardBody}>
                  <div style={styles.cardMeta}>
                    <span style={styles.cardMetaChip}>{Icons.User} {inv.doctor_name}</span>
                  </div>
                  <h3 style={styles.cardTitle}>{inv.idea_title}</h3>
                  <div style={styles.infoRow}>
                    <span style={styles.infoIcon}>{Icons.User}</span>
                    <div>
                      <span style={styles.infoLabel}>Invited by Team Leader</span>
                      <span style={styles.infoValue}>{inv.leader_name}</span>
                    </div>
                  </div>
                </div>

                <div style={styles.noticeBar}>
                  <span style={styles.noticeIcon}>{Icons.Briefcase}</span>
                  <span>Accepting means you won't be able to apply elsewhere until this application is decided. If rejected, you'll be free again.</span>
                </div>

                <div style={styles.cardActions}>
                  <button
                    className="btn btn-primary btn-sm"
                    style={styles.actionBtn}
                    onClick={() => handleIdeaRespond(inv.id, 'accept')}
                    disabled={acting === inv.id}
                  >
                    {Icons.Check} Accept
                  </button>
                  <button
                    className="btn btn-outline btn-sm"
                    style={{ ...styles.actionBtn, color: 'var(--danger)', borderColor: 'var(--danger)' }}
                    onClick={() => handleIdeaRespond(inv.id, 'reject')}
                    disabled={acting === inv.id}
                  >
                    {Icons.X} Decline
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Student proposal invitations */}
      {propInvs.length > 0 && (
        <div>
          <p style={styles.sectionLabel}>Student Proposal Teams</p>
          <div style={styles.cardList}>
            {propInvs.map((inv) => (
              <div key={inv.id} style={styles.card}>
                <div style={styles.cardBody}>
                  <h3 style={styles.cardTitle}>{inv.idea_title}</h3>
                  <div style={styles.infoRow}>
                    <span style={styles.infoIcon}>{Icons.User}</span>
                    <div>
                      <span style={styles.infoLabel}>Proposed by Team Leader</span>
                      <span style={styles.infoValue}>{inv.leader_name}</span>
                    </div>
                  </div>
                </div>

                <div style={styles.noticeBar}>
                  <span style={styles.noticeIcon}>{Icons.Briefcase}</span>
                  <span>Accepting means you won't be able to apply elsewhere until this proposal is decided. If rejected, you'll be free again.</span>
                </div>

                <div style={styles.cardActions}>
                  <button
                    className="btn btn-primary btn-sm"
                    style={styles.actionBtn}
                    onClick={() => handlePropRespond(inv.id, 'accept')}
                    disabled={acting === inv.id}
                  >
                    {Icons.Check} Accept
                  </button>
                  <button
                    className="btn btn-outline btn-sm"
                    style={{ ...styles.actionBtn, color: 'var(--danger)', borderColor: 'var(--danger)' }}
                    onClick={() => handlePropRespond(inv.id, 'reject')}
                    disabled={acting === inv.id}
                  >
                    {Icons.X} Decline
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
