import React, { useState, useEffect } from 'react';
import { studentSelfRegister } from '../api';
import './Login.css';
import './SelfRegister.css';

export default function SelfRegister({ onRegistered, onBack }) {
  const [form, setForm] = useState({ university_id: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [mounted, setMounted] = useState(false);
  const [focusedField, setFocusedField] = useState(null);

  useEffect(() => {
    const t = setTimeout(() => setMounted(true), 100);
    return () => clearTimeout(t);
  }, []);

  const set = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await studentSelfRegister(form.university_id, form.password);
      localStorage.setItem('access', res.data.access);
      localStorage.setItem('refresh', res.data.refresh);
      const payload = JSON.parse(atob(res.data.access.split('.')[1]));
      onRegistered({
        username: payload.username,
        role: payload.role,
        must_change_password: payload.must_change_password,
        department: payload.department,
      });
    } catch (err) {
      setError(err.response?.data?.error || 'Verification failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={`lp-wrapper ${mounted ? 'lp-mounted' : ''}`}>
      {/* Animated background particles */}
      <div className="lp-particles" aria-hidden="true">
        {[...Array(6)].map((_, i) => (
          <div key={i} className={`lp-particle lp-particle-${i + 1}`} />
        ))}
      </div>

      {/* Gradient overlay */}
      <div className="lp-overlay" />

      {/* Content */}
      <div className="lp-content">
        {/* Left branding panel */}
        <div className={`lp-brand ${mounted ? 'lp-brand-visible' : ''}`}>
          <div className="lp-brand-badge">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M22 10v6M2 10l10-5 10 5-10 5z" /><path d="M6 12v5c0 2 6 3 6 3s6-1 6-3v-5" />
            </svg>
            <span>SPU</span>
          </div>

          <div className="lp-brand-text">
            <h1>Join the Portal</h1>
            <div className="lp-brand-divider" />
            <p className="lp-brand-tagline">
              Verify your university credentials<br />and get instant access to the platform.
            </p>
          </div>

          <div className="lp-brand-features">
            <div className="lp-feature">
              <div className="lp-feature-icon" style={{ background: 'linear-gradient(135deg, rgba(34,211,238,0.2), rgba(59,130,246,0.2))' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ color: '#67e8f9' }}>
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                </svg>
              </div>
              <div>
                <strong>Secure Verification</strong>
                <span>University ID + Password</span>
              </div>
            </div>
            <div className="lp-feature">
              <div className="lp-feature-icon" style={{ background: 'linear-gradient(135deg, rgba(52,211,153,0.2), rgba(16,185,129,0.2))' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ color: '#6ee7b7' }}>
                  <polyline points="20 6 9 17 4 12" />
                </svg>
              </div>
              <div>
                <strong>Instant Access</strong>
                <span>No approval wait time</span>
              </div>
            </div>
            <div className="lp-feature">
              <div className="lp-feature-icon">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" /><rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" />
                </svg>
              </div>
              <div>
                <strong>Ready to Start</strong>
                <span>Browse ideas & build projects</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right card */}
        <div className={`lp-card ${mounted ? 'lp-card-visible' : ''}`}>
          <div className="lp-card-glow" aria-hidden="true" />

          <div className="lp-card-inner">
            {/* Mobile-only branding */}
            <div className="lp-mobile-brand">
              <div className="lp-mobile-logo">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M22 10v6M2 10l10-5 10 5-10 5z" /><path d="M6 12v5c0 2 6 3 6 3s6-1 6-3v-5" />
                </svg>
              </div>
              <span>SPU Portal</span>
            </div>

            <div className="lp-card-header">
              <h2>Student Verification</h2>
              <p>Verify your identity to create your account</p>
            </div>

            <div className="sr-info-glass">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0, marginTop: 2 }}>
                <circle cx="12" cy="12" r="10" /><line x1="12" y1="16" x2="12" y2="12" /><line x1="12" y1="8" x2="12.01" y2="8" />
              </svg>
              <span>Enter your University ID and password to verify your eligibility. Access will be granted automatically.</span>
            </div>

            <form onSubmit={handleSubmit} className="lp-form" noValidate>
              {error && (
                <div className="lp-error" role="alert">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="10" /><line x1="15" y1="9" x2="9" y2="15" /><line x1="9" y1="9" x2="15" y2="15" />
                  </svg>
                  {error}
                </div>
              )}

              <div className={`lp-field ${focusedField === 'university_id' ? 'lp-field-focused' : ''} ${form.university_id ? 'lp-field-filled' : ''}`}>
                <label htmlFor="university_id">University ID</label>
                <div className="lp-input-wrap">
                  <svg className="lp-input-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="2" y="5" width="20" height="14" rx="2" /><line x1="2" y1="10" x2="22" y2="10" />
                  </svg>
                  <input
                    id="university_id"
                    type="text"
                    placeholder=" "
                    value={form.university_id}
                    onChange={set('university_id')}
                    onFocus={() => setFocusedField('university_id')}
                    onBlur={() => setFocusedField(null)}
                    required
                    autoComplete="off"
                  />
                </div>
              </div>

              <div className={`lp-field ${focusedField === 'password' ? 'lp-field-focused' : ''} ${form.password ? 'lp-field-filled' : ''}`}>
                <label htmlFor="sr_password">Password</label>
                <div className="lp-input-wrap">
                  <svg className="lp-input-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" />
                  </svg>
                  <input
                    id="sr_password"
                    type="password"
                    placeholder=" "
                    value={form.password}
                    onChange={set('password')}
                    onFocus={() => setFocusedField('password')}
                    onBlur={() => setFocusedField(null)}
                    required
                    autoComplete="current-password"
                  />
                </div>
              </div>

              <button className="lp-submit" type="submit" disabled={loading}>
                <span className="lp-submit-text">
                  {loading ? 'Verifying...' : 'Verify & Access Portal'}
                </span>
                {loading && <span className="lp-submit-spinner" />}
                {!loading && (
                  <svg className="lp-submit-arrow" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <line x1="5" y1="12" x2="19" y2="12" /><polyline points="12 5 19 12 12 19" />
                  </svg>
                )}
              </button>

              <button type="button" className="sr-back-btn" onClick={onBack}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="19" y1="12" x2="5" y2="12" /><polyline points="12 19 5 12 12 5" />
                </svg>
                Back to Login
              </button>
            </form>

            <footer className="lp-footer">
              &copy; {new Date().getFullYear()} Syrian Private University &middot; Faculty of AI Engineering
            </footer>
          </div>
        </div>
      </div>
    </div>
  );
}
